import 'package:flutter/material.dart';

class HScreen extends StatelessWidget {
  List<Map<String, dynamic>> data = [
    {
      "image":
      "https://images.unsplash.com/photo-1682687982141-0143020ed57a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHwyMXx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=60",
      "name1": "aaaa",
      "description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries",
      "name2": "aaaa",
      "images": [
        "https://images.unsplash.com/photo-1682687982141-0143020ed57a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHwyMXx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=60",
        "https://images.unsplash.com/photo-1682687982141-0143020ed57a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHwyMXx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=60",
        "https://images.unsplash.com/photo-1682687982141-0143020ed57a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHwyMXx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=60"
      ],
      "name3": ""
    },
  ];

  HScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        leading: Icon(Icons.arrow_back_ios_rounded),
        actions: [
          Icon(Icons.menu),
        ],
      ),
      body: Container(
        margin: EdgeInsets.all(15),
        child: SingleChildScrollView(
          child: Column(
            children: data
                .map(
                  (e) => Screen(
                e["image"],
                e["name1"],
                e["name2"],
                e["name3"],
                e["images"],
                e["description"],
              ),
            )
                .toList(),
          ),
        ),
      )
    );
  }
}

class Screen extends StatelessWidget {
  String? imageUrl;
  String? name1, name2, name3, description;
  List<String>? images;

  Screen(this.imageUrl, this.name1, this.name2, this.name3, this.images,
      this.description);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Image.network(imageUrl ?? "", width: double.infinity,height: 300,fit: BoxFit.cover,),
        SizedBox(height: 10,),
        Align(alignment: Alignment.centerLeft,
            child: Text(name1 ?? '',style: TextStyle(fontWeight: FontWeight.bold) ,textAlign: TextAlign.left,)),
        SizedBox(height: 10,),
        Text(description ?? ''),
        Text(name2 ?? '',textAlign: TextAlign.left,),
        Row(
          children: [
            Container(
              decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(10))),
              child: Image.network(images![0],width: 50,height: 50,fit: BoxFit.cover,),),
            SizedBox(width: 10,),
            Container(
              decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(10))),
              child: Image.network(images![1],width: 50,height: 50,fit: BoxFit.cover,),),
            SizedBox(width: 10,),
            Container(
              decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(10))),
              child: Image.network(images![2],width: 50,height: 50,fit: BoxFit.cover,),),


          ],
        ),
        Text(name3 ?? '',textAlign: TextAlign.left,),
      ],
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: HScreen(),
  ));
}
